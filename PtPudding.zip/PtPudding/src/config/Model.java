/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package config;

import javax.swing.DefaultComboBoxModel;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author codemint
 */
public class Model {

    public static void refreshRowDefaultTableModel(DefaultTableModel model) {
        int row = model.getRowCount();
        for (int i = 0; i < row; i++) {
            model.removeRow(0);
        }
    }

    public static void refreshRowDefaultComboBoxModel(DefaultComboBoxModel model, String selectedTitle) {
        int row = model.getSize();
        model.setSelectedItem(selectedTitle);
        for (int i = 0; i < row; i++) {
            model.removeElementAt(0);
        }
    }

}
