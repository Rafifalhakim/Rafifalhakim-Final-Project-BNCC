/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package config.server;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;
import javax.swing.JOptionPane;

/**
 *
 * @author codemint
 */
public class KoneksiDB {

    private java.sql.Connection conn;

    public Connection createConnection() {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Properties props = new Properties();
            props.put("user", "codemint");// ganti ke *root*
            props.put("password", "135792468");// dikosongin aja
            String DB_URL = "jdbc:mysql://localhost:3306/pt_pudding";
            conn = DriverManager.getConnection(DB_URL, props);
        } catch (ClassNotFoundException | SQLException e) {
            JOptionPane.showMessageDialog(null, "Gagal Menghubungkan Server Database.\nPesan: "
                    + e.getMessage(), "Terjadi Kesalahan", JOptionPane.ERROR_MESSAGE);
        }
        return conn;
    }

}
